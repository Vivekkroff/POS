const ClientDetails = () => {
  return (
    <div className="client-details">
      <h1>Client Details</h1>
      <div className="client-content">
        {/* Client details content */}
      </div>
    </div>
  );
};

export default ClientDetails; 