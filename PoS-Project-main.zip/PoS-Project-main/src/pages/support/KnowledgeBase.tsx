import React from 'react';

const KnowledgeBase: React.FC = () => {
  return (
    <div>
      <h1>Knowledge Base</h1>
      {/* Add your knowledge base content here */}
    </div>
  );
};

export default KnowledgeBase; 