import React from 'react';

const Tickets: React.FC = () => {
  return (
    <div>
      <h1>Support Tickets</h1>
      {/* Add your tickets management content here */}
    </div>
  );
};

export default Tickets; 