const AnalyticsView = () => {
  return (
    <div className="analytics-view">
      <h1>Analytics</h1>
      <div className="analytics-content">
        {/* Analytics content */}
      </div>
    </div>
  );
};

export default AnalyticsView; 