export const Performance = () => {
  return (
    <div className="page-container">
      <h1>Performance Reports</h1>
      {/* Add your performance content here */}
    </div>
  );
};

export default Performance; 