export const SalesReports = () => {
  return (
    <div className="page-container">
      <h1>Sales Reports</h1>
      {/* Add your sales reports content here */}
    </div>
  );
};

export default SalesReports; 