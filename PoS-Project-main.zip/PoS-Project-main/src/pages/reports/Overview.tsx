export const Overview = () => {
  return (
    <div className="page-container">
      <h1>Reports Overview</h1>
      {/* Add your overview content here */}
    </div>
  );
};

export default Overview; 