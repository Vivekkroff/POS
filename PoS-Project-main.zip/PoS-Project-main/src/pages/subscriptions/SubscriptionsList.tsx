const SubscriptionsList = () => {
  return (
    <div className="subscriptions-page">
      <h1>Subscriptions</h1>
      <div className="subscriptions-content">
        {/* Subscriptions list content */}
      </div>
    </div>
  );
};

export default SubscriptionsList; 