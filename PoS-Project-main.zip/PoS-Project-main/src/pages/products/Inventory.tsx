import React from 'react';

const Inventory: React.FC = () => {
  return (
    <div>
      <h1>Inventory Management</h1>
      {/* Add your inventory management content here */}
    </div>
  );
};

export default Inventory; 