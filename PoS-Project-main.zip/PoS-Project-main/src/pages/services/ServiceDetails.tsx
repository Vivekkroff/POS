const ServiceDetails = () => {
  return (
    <div className="service-details">
      <h1>Service Details</h1>
      <div className="service-content">
        {/* Service details content */}
      </div>
    </div>
  );
};

export default ServiceDetails; 