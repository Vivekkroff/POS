const ServicesList = () => {
  return (
    <div className="services-page">
      <h1>Services</h1>
      <div className="services-content">
        {/* Add services content here */}
      </div>
    </div>
  );
};

export default ServicesList; 