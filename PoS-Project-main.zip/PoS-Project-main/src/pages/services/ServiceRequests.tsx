const ServiceRequests = () => {
  return (
    <div className="page-container">
      <h1>Service Requests</h1>
      {/* Add your service requests content here */}
    </div>
  );
};

export default ServiceRequests; 